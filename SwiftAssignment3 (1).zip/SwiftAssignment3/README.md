# SwiftAssignment3

Swift Development Assignment 3 playground.

## Contents

- `SwiftAssignment3.playground/Contents.swift` — Swift code for the Computer class, subclasses, enum, protocol, and custom RAM operator.
- `AIReflection.md` — AI usage and reflection section.

## How to Use

1. Open `SwiftAssignment3.playground` in Xcode.
2. Run the playground.
3. Review the printed system summaries.
4. Edit `AIReflection.md` so it accurately reflects your own process before submitting.
