import Foundation

// MARK: - Architecture Enumeration

/// Represents supported CPU architectures for a computer.
enum Architecture: String {
    case x86_64
    case AMD64
    case aarch64
    case ppc64
    case riscv64
}

// MARK: - ComputerSystem Protocol

/// Defines the common properties that all computer systems should have.
protocol ComputerSystem {
    var manufacturer: String { get }
    var model: String { get }
    var architecture: Architecture { get set }
    var processor: String { get set }
    var storageGB: Int { get set }
    var memoryGB: Int { get set }
    var operatingSystem: String { get set }

    func systemSummary() -> String
}

// MARK: - Custom RAM Operator

infix operator ~~: AssignmentPrecedence

/// Sets RAM in increments of 8 GB.
/// Example: `computer ~~ 4` sets the computer's memory to 32 GB.
func ~~ (computer: Computer, unitsOfEightGB: Int) {
    guard unitsOfEightGB > 0 else {
        print("RAM must be set using a positive number of 8 GB units.")
        return
    }

    computer.memoryGB = unitsOfEightGB * 8
}

// MARK: - Base Class

/// A general computer class containing properties common to all computers.
class Computer: ComputerSystem {
    let manufacturer: String
    let model: String
    var architecture: Architecture
    var processor: String
    var storageGB: Int
    var memoryGB: Int
    var operatingSystem: String

    init(
        manufacturer: String,
        model: String,
        architecture: Architecture,
        processor: String,
        storageGB: Int,
        memoryGB: Int,
        operatingSystem: String
    ) {
        self.manufacturer = manufacturer
        self.model = model
        self.architecture = architecture
        self.processor = processor
        self.storageGB = storageGB
        self.memoryGB = memoryGB
        self.operatingSystem = operatingSystem
    }

    func systemSummary() -> String {
        return """
        \(manufacturer) \(model)
        Architecture: \(architecture.rawValue)
        Processor: \(processor)
        RAM: \(memoryGB) GB
        Storage: \(storageGB) GB
        OS: \(operatingSystem)
        """
    }
}

// MARK: - Subclasses

/// A gaming PC with gaming-specific hardware information.
final class GamingPC: Computer {
    var graphicsCard: String
    var hasRGBLighting: Bool
    var coolingType: String

    init(
        manufacturer: String,
        model: String,
        architecture: Architecture,
        processor: String,
        storageGB: Int,
        memoryGB: Int,
        operatingSystem: String,
        graphicsCard: String,
        hasRGBLighting: Bool,
        coolingType: String
    ) {
        self.graphicsCard = graphicsCard
        self.hasRGBLighting = hasRGBLighting
        self.coolingType = coolingType

        super.init(
            manufacturer: manufacturer,
            model: model,
            architecture: architecture,
            processor: processor,
            storageGB: storageGB,
            memoryGB: memoryGB,
            operatingSystem: operatingSystem
        )
    }

    override func systemSummary() -> String {
        return super.systemSummary() + """

        Graphics Card: \(graphicsCard)
        RGB Lighting: \(hasRGBLighting ? "Yes" : "No")
        Cooling: \(coolingType)
        """
    }
}

/// A workstation designed for professional production workloads.
final class Workstation: Computer {
    var professionalGPU: String
    var supportsECCMemory: Bool
    var intendedUse: String

    init(
        manufacturer: String,
        model: String,
        architecture: Architecture,
        processor: String,
        storageGB: Int,
        memoryGB: Int,
        operatingSystem: String,
        professionalGPU: String,
        supportsECCMemory: Bool,
        intendedUse: String
    ) {
        self.professionalGPU = professionalGPU
        self.supportsECCMemory = supportsECCMemory
        self.intendedUse = intendedUse

        super.init(
            manufacturer: manufacturer,
            model: model,
            architecture: architecture,
            processor: processor,
            storageGB: storageGB,
            memoryGB: memoryGB,
            operatingSystem: operatingSystem
        )
    }

    override func systemSummary() -> String {
        return super.systemSummary() + """

        Professional GPU: \(professionalGPU)
        ECC Memory Support: \(supportsECCMemory ? "Yes" : "No")
        Intended Use: \(intendedUse)
        """
    }
}

/// A server class with properties focused on network and data-center use.
final class Server: Computer {
    var rackUnits: Int
    var networkPorts: Int
    var supportsVirtualization: Bool

    init(
        manufacturer: String,
        model: String,
        architecture: Architecture,
        processor: String,
        storageGB: Int,
        memoryGB: Int,
        operatingSystem: String,
        rackUnits: Int,
        networkPorts: Int,
        supportsVirtualization: Bool
    ) {
        self.rackUnits = rackUnits
        self.networkPorts = networkPorts
        self.supportsVirtualization = supportsVirtualization

        super.init(
            manufacturer: manufacturer,
            model: model,
            architecture: architecture,
            processor: processor,
            storageGB: storageGB,
            memoryGB: memoryGB,
            operatingSystem: operatingSystem
        )
    }

    override func systemSummary() -> String {
        return super.systemSummary() + """

        Rack Units: \(rackUnits)U
        Network Ports: \(networkPorts)
        Virtualization Support: \(supportsVirtualization ? "Yes" : "No")
        """
    }
}

// MARK: - Testing the Classes

let gamingComputer = GamingPC(
    manufacturer: "CustomBuild",
    model: "NightBlade X",
    architecture: .AMD64,
    processor: "AMD Ryzen 7",
    storageGB: 2000,
    memoryGB: 16,
    operatingSystem: "Windows 11",
    graphicsCard: "NVIDIA GeForce RTX 4070",
    hasRGBLighting: true,
    coolingType: "Liquid Cooling"
)

gamingComputer ~~ 4 // 4 increments of 8 GB = 32 GB RAM
print(gamingComputer.systemSummary())

let workstation = Workstation(
    manufacturer: "Lenovo",
    model: "ThinkStation P Series",
    architecture: .x86_64,
    processor: "Intel Xeon",
    storageGB: 4000,
    memoryGB: 64,
    operatingSystem: "Ubuntu Linux",
    professionalGPU: "NVIDIA RTX A4000",
    supportsECCMemory: true,
    intendedUse: "3D rendering and software development"
)

workstation ~~ 8 // 8 increments of 8 GB = 64 GB RAM
print(workstation.systemSummary())

let webServer = Server(
    manufacturer: "Dell",
    model: "PowerEdge R650",
    architecture: .riscv64,
    processor: "Multi-core Server CPU",
    storageGB: 8000,
    memoryGB: 128,
    operatingSystem: "Red Hat Enterprise Linux",
    rackUnits: 1,
    networkPorts: 4,
    supportsVirtualization: true
)

webServer ~~ 16 // 16 increments of 8 GB = 128 GB RAM
print(webServer.systemSummary())
