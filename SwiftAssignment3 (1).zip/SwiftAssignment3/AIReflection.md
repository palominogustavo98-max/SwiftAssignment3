# AI Reflection

## 1. How Did You Use AI in This Assignment?

I used AI as a helper and reference while working on the assignment. I mainly used it to help me organize the Swift code structure and understand how the class, subclass, enum, protocol, and custom operator requirements could fit together.

One prompt I used was something like: “Help me create Swift classes for a Computer assignment using inheritance, an enum, a protocol, and a custom operator.” I did not want to only copy the result without understanding it, so I reviewed the code and made sure I understood what each part was doing.

One concept I needed to look at more carefully was the custom operator. I reviewed how Swift lets you define an operator with `infix operator` and then write a function for how the operator behaves.

## 2. How Did You Understand, Verify, and Adapt the Code?

I verified the code by running it in an Xcode playground and checking the printed output. I tested whether the custom RAM operator actually changed the memory value in increments of 8 GB. For example, using `gamingComputer ~~ 4` should set the RAM to 32 GB.

I also checked that each subclass had properties specific to that type of computer. For example, `GamingPC` has a graphics card and cooling type, while `Server` has rack units, network ports, and virtualization support.

One improvement I made was keeping the shared computer properties in the main `Computer` class instead of repeating them in every subclass. This made the code cleaner and showed how inheritance helps avoid duplication.

## 3. What Did You Learn or Get Better At Through This Work?

I got more comfortable with how classes and subclasses work together in Swift. I better understand that the base class should contain the common information, while subclasses should only add the details that make them different.

I also learned more about protocols. The `ComputerSystem` protocol helped me think about what properties and behavior every computer system should have.

The custom operator was the most difficult part because it was new to me. After testing it, I understood that an operator is basically another way to call a function, but with a custom symbol. What went well was building the class structure. What took more effort was understanding the correct syntax for the custom operator and making sure the code still stayed readable.
